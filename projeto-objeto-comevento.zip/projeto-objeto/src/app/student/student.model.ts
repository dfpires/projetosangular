export class Student {

  name: string
  isRegular: boolean
  address?: string
}
