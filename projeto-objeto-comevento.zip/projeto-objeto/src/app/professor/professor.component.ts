import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'dfp-professor',
  templateUrl: './professor.component.html',
  styleUrls: ['./professor.component.css']
})
export class ProfessorComponent implements OnInit {

  @Input() name: String
  @Input() isDoctor: boolean

  constructor() { }

  ngOnInit() {
  }

}
