import { Component } from '@angular/core';
import {Student} from './student/student.model'

@Component({
  selector: 'dfp-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'dfp';


  daniel = {name: 'Daniel', isRegular: true, address: 'Franca'}
  alex = {name: 'Alex', isRegular: false, address: 'Pedregulho'}
  marcelo = {name: 'Marcelo', isRegular: false, address: 'Rio de Janeiro'}

  students: Student[] = [
    {name: 'Daniel', isRegular: true, address: 'Franca'},
    {name: 'Alex', isRegular: false, address: 'Pedregulho'},
    {name: 'Marcelo', isRegular: false, address: 'Rio de Janeiro'}
  ]



}
