import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dfp-disciplina',
  templateUrl: './disciplina.component.html',
  styleUrls: ['./disciplina.component.css']
})
export class DisciplinaComponent implements OnInit {

  name: string = "Desenvolvimento Web"
  isRegular: boolean = true
  carga: number = 4

  constructor() { }

  ngOnInit() {
  }

}
